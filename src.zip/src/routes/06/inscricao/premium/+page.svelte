<h1>Plano Quantum (Premium)</h1>
<p>O máximo em desempenho e recursos. Suporte prioritário incluso.</p>
<p style="color: green;">Pagamento aprovado. Bem-vindo(a) ao Plano Quantum!</p>
