<h1>Plano Bit (Básico)</h1>
<p>Ideal para iniciantes. Acesso limitado, mas eficiente.</p>
<p style="color: green;">Pagamento aprovado. Bem-vindo(a) ao Plano Bit!</p>
