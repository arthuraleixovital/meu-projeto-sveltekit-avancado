<script>
    let { data } = $props();
  </script>
  {data.w} {data.x} {data.y} {data.z}