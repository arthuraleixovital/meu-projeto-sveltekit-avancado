export function load({ params }) {
    const parametro1 = params.rota;
    const parametro2 = params.dinamica;
   
    return { parametro1, parametro2 };
  }