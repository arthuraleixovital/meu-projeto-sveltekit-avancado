<form action="/03/formulario-recebendo">
    <input name="fruta" placeholder="Qual tua fruta preferida?" />
    <input name="legume" placeholder="E legume?" />
    <button>Enviar</button>
  </form>
   
  <p><a href="/03/formulario-recebendo">Ir</a></p>