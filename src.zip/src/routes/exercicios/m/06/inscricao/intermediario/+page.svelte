<script>
    export let form = {};
  </script>
  
  <h2>Plano Byte (Intermediário)</h2>
  <p>Pagamento aprovado. Bem-vindo(a) ao Plano Byte!</p>
  