<script>
    let { data } = $props();
  </script>
  {data.b} {data.d} {data.e}