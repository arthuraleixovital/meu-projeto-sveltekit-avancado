export function load() {
    return {
      post: { title: 'Título de Exemplo', content: 'Conteúdo <b>supimpa</b> de Exemplo' },
      author: { name: 'Autor Exemplo', email: 'autor@exemplo.com' }
    };
  }