<script>
    let { data } = $props();
  </script>
   
  <p>Parâmetros de rota:</p>
  <ul><li>{data.rp1}</li><li>{data.rp2}</li></ul>
   
  <p>Parâmetros de busca:</p>
  <ul><li>{data.sp1}</li><li>{data.sp2}</li></ul>