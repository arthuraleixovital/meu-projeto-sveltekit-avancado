<script>
    export let form = {};
  </script>
  
  <h2>Plano Quantum (Premium)</h2>
  <p>Pagamento aprovado. Bem-vindo(a) ao Plano Quantum!</p>
  