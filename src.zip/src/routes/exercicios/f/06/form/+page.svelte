<form method="POST" action="/06/post">
    <input type="number" placeholder="Digite um número" />
    <input name="umtexto" placeholder="Digite um texto" />
    <input name="umadata" type="date" />
    <button>Enviar</button>
  </form>