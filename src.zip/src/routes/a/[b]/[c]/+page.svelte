<script>
  let { data } = $props();
</script>
{data.x} {data.y} {data.z}